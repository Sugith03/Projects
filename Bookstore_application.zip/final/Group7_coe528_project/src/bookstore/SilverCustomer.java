/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author sugithkandiah and rohanbhatia
 */
public class SilverCustomer extends CustomerStatus {
    private String stat;

    public SilverCustomer() {
        stat = "Silver";
    }
    
    @Override
    public void changeStatus(Customer c){
        c.setState(new GoldCustomer());
    }

    @Override
    public String currentStatus(){
        return stat;
    }
}
